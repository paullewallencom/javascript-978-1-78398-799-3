class UserManager{
  constructor(public database, public userEmailer){

  }
}

class Database{}

  class UserEmailer{}
