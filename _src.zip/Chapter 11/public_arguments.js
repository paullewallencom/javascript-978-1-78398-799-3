var Axe = (function () {
    function Axe(handleLength, headHeight) {
        this.handleLength = handleLength;
        this.headHeight = headHeight;
    }
    return Axe;
})();
