var PageModel = (function () {
    function PageModel() {
    }
    return PageModel;
})();

var User = (function () {
    function User() {
    }
    return User;
})();
