class Castle{
 constructor(public name){
  }
 public Build(){
  console.log("Castle built: " + this.name);
 }
}
