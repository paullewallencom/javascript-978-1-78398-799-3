var b = 6;
c = 7;